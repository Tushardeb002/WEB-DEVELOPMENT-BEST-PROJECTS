

export const Navbar = () => {



    return (
        <div className='navbox'>
            <div className='leftside'>
                <img src="logobg.png" alt="" />
            </div>

                <span className='no-of-products'></span>
                <span><button className='logout-btn' >Logout</button></span>
        </div>
    )
}
