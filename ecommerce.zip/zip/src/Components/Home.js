

export const Home = ({ user }) => {



    return (
        <>
            <Navbar  />
            
            <Products />
            </>
 
  

           
       
    )
}
